// a simple bit of math

